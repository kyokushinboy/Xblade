# 🛡️ XBlade - Advanced XSS Scanner (CLI)

**XBlade** یک ابزار پیشرفته، سریع و حرفه‌ای برای شناسایی آسیب‌پذیری‌های Cross-Site Scripting (XSS) در برنامه‌های وب است که به صورت کامل از خط فرمان (CLI) قابل استفاده است.

---

## ✨ ویژگی‌ها

- پشتیبانی از Reflected و DOM-based XSS
- پشتیبانی از بای‌پس فیلترهای ساده
- طراحی ماژولار و قابل توسعه
- تولید گزارش‌های HTML و متنی
- مناسب برای تست نفوذ، ریسک‌سنجی و تحلیل امنیتی
- بدون نیاز به رابط گرافیکی، کاملاً CLI

---

## 📦 نصب

```bash
git clone https://github.com/yourname/xblade.git
cd xblade
pip install -r requirements.txt
