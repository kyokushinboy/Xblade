# xblade/cli/interface.py

import argparse
from core.scanner import XSSScanner

def run_cli():
    parser = argparse.ArgumentParser(
        description="XBlade - Advanced XSS Scanner (CLI)"
    )

    parser.add_argument("-u", "--url", required=True, help="Target URL (e.g., http://site.com/page.php?test=1)")
    parser.add_argument("-d", "--data", help="POST data (if any)")
    parser.add_argument("--cookie", help="Cookies to use (e.g., PHPSESSID=123)")
    parser.add_argument("--user-agent", help="Custom User-Agent header")
    parser.add_argument("--method", choices=["GET", "POST"], default="GET", help="Request method to use")
    parser.add_argument("--report", choices=["html", "json"], help="Generate report in format")
    parser.add_argument("--bypass", action="store_true", help="Enable filter bypass plugins")
    parser.add_argument("--timeout", type=int, default=10, help="Request timeout (seconds)")

    args = parser.parse_args()

    scanner = XSSScanner(
        url=args.url,
        method=args.method,
        data=args.data,
        cookies=args.cookie,
        user_agent=args.user_agent,
        timeout=args.timeout,
        use_bypass=args.bypass
    )
    scanner.run()

    if args.report:
        from reporting.reporter import generate_report
        generate_report(scanner.results, fmt=args.report)

