from core.scanner import XSSScanner
from core.utils import log_info, log_error

def main():
    print(r"""
__  __   _      _               _    
\ \/ /  | |__  | |   _____   __| |    ___
 \  /   | '_ \ | |  / __ |  / _  |   / _ \
 /  \   | |_)| | |   / _ |  |(_| |  |  __/
/_/\_\  |_.__/ |_|   \___|  \____|   \___|

  🔥 XBlade - Advanced XSS Scanner 🔥
    """)

    url = input("🔗 Enter the target URL (e.g., http://site.com/index.php?q=): ").strip()

    print(f"[INFO] Target URL: {url}")
    print("[INFO] Starting XBlade Scanner...")

    try:
        scanner = XSSScanner(
            url=url,
            use_bypass=False
        )

        scanner.run()

    except KeyboardInterrupt:
        log_error("Scan interrupted by user.")
    except Exception as e:
        log_error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
