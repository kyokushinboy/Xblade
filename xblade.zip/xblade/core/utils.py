# xblade/core/utils.py

import sys

# رنگ‌ها برای CLI
class Colors:
    RESET = '\033[0m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    GRAY = '\033[90m'

# توابع لاگ
def log_info(msg):
    print(f"{Colors.BLUE}[INFO]{Colors.RESET} {msg}")

def log_warning(msg):
    print(f"{Colors.YELLOW}[WARN]{Colors.RESET} {msg}")

def log_error(msg):
    print(f"{Colors.RED}[ERROR]{Colors.RESET} {msg}", file=sys.stderr)

def log_vuln(msg):
    print(f"{Colors.GREEN}[VULNERABLE]{Colors.RESET} {msg}")

def log_debug(msg):
    print(f"{Colors.GRAY}[DEBUG]{Colors.RESET} {msg}")

# ابزار کمکی دیگر در آینده اضافه خواهد شد
