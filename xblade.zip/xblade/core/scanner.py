# xblade/core/scanner.py

import re
import time
import urllib.parse
import requests
from bs4 import BeautifulSoup
from core.payloads import XSS_PAYLOADS
from core.request_handler import RequestHandler
from plugins.bypass_filters import apply_bypass_plugins
from core.utils import log_info, log_vuln, log_error

class XSSScanner:
    def __init__(self, url, method="GET", data=None, cookies=None, user_agent=None, timeout=10, use_bypass=False):
        self.url = url
        self.method = method.upper()
        self.data = data
        self.cookies = self._parse_cookies(cookies)
        self.user_agent = user_agent or "XBlade Scanner"
        self.timeout = timeout
        self.use_bypass = use_bypass

        self.results = []  # برای گزارش‌گیری

        self.req = RequestHandler(
            cookies=self.cookies,
            user_agent=self.user_agent,
            timeout=self.timeout
        )

    def _parse_cookies(self, cookie_string):
        if not cookie_string:
            return {}
        cookies = {}
        for item in cookie_string.split(";"):
            if "=" in item:
                k, v = item.strip().split("=", 1)
                cookies[k] = v
        return cookies

    def _inject_payload(self, url, payload):
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)

        for key in query:
            query[key] = payload

        new_query = urllib.parse.urlencode(query, doseq=True)
        new_url = urllib.parse.urlunparse(parsed._replace(query=new_query))

        return new_url

    def run(self):
        log_info(f"Target: {self.url}")
        log_info(f"Method: {self.method}")
        log_info("Starting XSS scan...")

        for payload in XSS_PAYLOADS:
            attack_payload = payload
            if self.use_bypass:
                attack_payload = apply_bypass_plugins(payload)

            target_url = self._inject_payload(self.url, attack_payload)

            try:
                if self.method == "GET":
                    response = self.req.send_get(target_url)
                else:
                    post_data = self.data or ""
                    post_data = post_data.replace("{{X}}", attack_payload)
                    response = self.req.send_post(self.url, post_data)
            except requests.RequestException as e:
                log_error(f"Request failed: {e}")
                continue

            if self._detect_xss(response.text, attack_payload):
                log_vuln(f"VULNERABLE with payload: {attack_payload}")
                self.results.append({
                    "payload": attack_payload,
                    "url": target_url,
                    "method": self.method,
                    "response_snippet": response.text[:500]
                })

        if not self.results:
            log_info("No XSS vulnerabilities found.")

    def _detect_xss(self, response_text, payload):
        soup = BeautifulSoup(response_text, "html.parser")
        if payload in response_text:
            return True
        if soup.find(text=re.compile(re.escape(payload))):
            return True
        return False
