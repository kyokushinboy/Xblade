# xblade/core/request_handler.py

import requests
from core.utils import log_debug, log_error

class RequestHandler:
    def __init__(self, cookies=None, user_agent=None, timeout=10):
        self.session = requests.Session()
        self.timeout = timeout

        self.headers = {
            "User-Agent": user_agent or "XBlade Scanner",
        }

        if cookies:
            self.session.cookies.update(cookies)

    def send_get(self, url):
        log_debug(f"Sending GET request to: {url}")
        response = self.session.get(url, headers=self.headers, timeout=self.timeout, verify=False)
        return response

    def send_post(self, url, data):
        log_debug(f"Sending POST request to: {url} with data: {data}")
        response = self.session.post(url, data=data, headers=self.headers, timeout=self.timeout, verify=False)
        return response
