# xblade/core/reporter.py

import os
from datetime import datetime

def save_text_report(vulnerabilities, output_path="xblade_report.txt"):
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("XBlade XSS Scanner Report\n")
        f.write("=" * 40 + "\n")
        f.write(f"Generated: {datetime.now()}\n\n")
        for item in vulnerabilities:
            f.write(f"URL: {item['url']}\n")
            f.write(f"Parameter: {item['param']}\n")
            f.write(f"Payload: {item['payload']}\n")
            f.write("-" * 30 + "\n")
    return output_path

def save_html_report(vulnerabilities, output_path="xblade_report.html"):
    html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>XBlade Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
        h1 {{ color: #2c3e50; }}
        .vuln-box {{ background: #fff; padding: 15px; margin-bottom: 10px; border-left: 5px solid #e74c3c; }}
        .meta {{ color: #555; font-size: 14px; }}
        code {{ background: #eee; padding: 2px 5px; border-radius: 3px; }}
    </style>
</head>
<body>
    <h1>XBlade XSS Vulnerability Report</h1>
    <p class="meta">Generated: {datetime.now()}</p>
"""

    for item in vulnerabilities:
        html += f"""
    <div class="vuln-box">
        <strong>URL:</strong> <code>{item['url']}</code><br>
        <strong>Parameter:</strong> <code>{item['param']}</code><br>
        <strong>Payload:</strong> <code>{item['payload']}</code>
    </div>
"""

    html += """
</body>
</html>
"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
